"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const handler = async (event) => {
    const memberId = event.pathParameters?.memberId;
    if (!memberId) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'memberId is required' }),
        };
    }
    const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: process.env.TABLE_NAME,
        KeyConditionExpression: 'PK = :pk',
        ExpressionAttributeValues: {
            ':pk': `MEMBER#${memberId}`,
        },
    }));
    return {
        statusCode: 200,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify(result.Items),
    };
};
exports.handler = handler;
